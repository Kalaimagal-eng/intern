package com.example.internapp.Internapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternappApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternappApplication.class, args);
	}

}
