package com.example.internapp.Internapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternappApplicationTests {

	@Test
	void contextLoads() {
	}

}
